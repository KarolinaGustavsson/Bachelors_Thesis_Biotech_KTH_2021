
# --------------------------------------------

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn.decomposition import PCA

# --------------------------------------------

file = "counts_fucci.tab"

table = pd.DataFrame(pd.read_csv(file, delimiter = '\t', header=None, dtype='a')) # import data from csv-file
table = table.drop([0], axis=1)                     # remove first column
table = table.drop([0], axis=0)                     # remove first row
table = table.drop([383,384], axis=1)               # remove samples without fucci-data

table_fucci = table.iloc[:1, :]                     # create matrix with only fucci-data
table_fucci = table_fucci.T                         # transpose the matrix
table_fucci = table_fucci.reset_index(drop=True)    # reset dataframe index

table = table.iloc[1: , :]                          # remove fucci-data from matrix
table = table.reset_index(drop=True)                # reset dataframe index

# --------------------------------------------

components = 2                                              # choose Nr. of columns for PCA
table = table.astype(np.float64)                            # turn DataFrame values into float64
table = (np.log(table)).replace(-np.inf, 0)                 # logarithm all values and if value is inf return 0
table = preprocessing.normalize(table, norm='max')          # normalize using norm-method

pca = PCA(n_components=components)                          # input Nr of components
pca = pca.fit(table)                                        # run PCA on normalized data
pca = pca.components_                                       # save PCA-data in new matrix

pca = pca.T                                                 # transpose PCA-matrix
table = pd.DataFrame(pca)                                   # save matrix as a DataFrame
table.columns = ["PC%s" %i for i in range(1,components+1)]  # rename columns

fucci = table_fucci[1]                                      # extract fucci-data as column
table = table_fucci.join(table)                             # join fucci-data with PCA-data
table.columns = ["Fucci", "PC1", "PC2"]                     # rename columns

# --------------------------------------------

table["color"] = np.where(table["Fucci"]=="Red", "red", "green")    # choose colors for plot

for col in [table]:                                                 # start loop for plot
    plt.scatter(col['PC1'], col['PC2'], color = table["color"])     # scatter-plot the data
plt.grid()                                                          # enable grid
plt.xlabel('PC1')                                                   # name x-label
plt.ylabel('PC2')                                                   # name y-label
plt.show()                                                          # show the plot

# --------------------------------------------
