# --------------------------------------------

import pandas as pd                                 # import pandas
import numpy as np                                  # import numpy
import matplotlib.pyplot as plt                     # import matplotlib (for plotting)
from sklearn import preprocessing                   # import part of sklearn
from sklearn.decomposition import PCA               # import PCA from sklearn

# --------------------------------------------

# This part imports the data from CSV-file

file = "counts_fucci.tab"                                           # choose what file to import data from

counts = pd.read_csv(file, delimiter = '\t', header=0, dtype='a')   # import data from csv-file
counts = counts.drop(['gene'], axis=1)                              # remove first column (gene)

# --------------------------------------------

# To remove fucci-info use this part!

table_fucci = counts.iloc[:1, :]                    # create matrix with only fucci-data
table_fucci = table_fucci.T                         # transpose the matrix
table_fucci = table_fucci.reset_index(drop=True)    # reset dataframe index

counts = counts.iloc[1: , :]                          # remove fucci-data from matrix
counts = counts.reset_index(drop=True)                # reset dataframe index

# --------------------------------------------

# This part creates three dataframes, counts (with all data), counts_P0 (with P0 data) and counts_P7 (with P7 data)

counts_list = counts.columns.tolist()                               # create list of column names in counts-file
counts_temp = ([y for y in counts_list if '01' in y],               # create list of P0-samples
       [y for y in counts if '02' in y],
       [y for y in counts if '03' in y],
       [y for y in counts if '04' in y],
       [y for y in counts if '05' in y],
       [y for y in counts if '06' in y],
       [y for y in counts if '07' in y],
       [y for y in counts if '08' in y])
counts_P0 = []                                                      # create empty list for P0
for sublist in counts_temp:                                         # add P0-samples to P0 list
    for item in sublist:
        counts_P0.append(item)
counts_P0 = sorted(counts_P0)                                       # sort list in alphabetical order
counts_P7 = np.setdiff1d(counts_list,counts_P0)                     # create P7-samples list

counts_P0 = counts[counts_P0]                                       # create matrix with P0-data
counts_P7 = counts[counts_P7]                                       # create matrix with P7-data

# --------------------------------------------
